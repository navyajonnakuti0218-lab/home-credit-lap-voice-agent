const fields = [
  ["propertyType","Property type"],["ownership","Ownership"],["documents","Original documents"],
  ["loanAmount","Requested loan amount"],["occupation","Occupation"],["incomeMode","Income mode"],
  ["marketValue","Estimated market value"],["tenure","Repayment tenure"]
];
let state = {
  stage:"identity", identityVerified:false, consent:false,
  answers:{propertyType:null,ownership:null,documents:null,loanAmount:null,occupation:null,incomeMode:null,marketValue:null,tenure:null},
  outcome:null, history:[{role:"assistant",text:"Hello, may I speak with the customer? I'm an AI voice assistant calling on behalf of Home Credit."}]
};
const chat = document.querySelector("#chat");
const form = document.querySelector("#chatForm");
const input = document.querySelector("#messageInput");
function addBubble(role,text){const el=document.createElement("div");el.className=`bubble ${role}`;el.textContent=text;chat.appendChild(el);chat.scrollTop=chat.scrollHeight;}
function labelValue(k,v){
 if(v===null||v===undefined)return "Not answered";
 if(k==="loanAmount"||k==="marketValue")return "₹"+Number(v).toLocaleString("en-IN");
 if(k==="documents")return v==="yes"?"Available":"Unavailable";
 if(k==="tenure")return `${v} years`;
 return String(v);
}
function render(){
 const list=document.querySelector("#checklist");list.innerHTML="";
 fields.forEach(([key,label])=>{const v=state.answers[key];const el=document.createElement("div");el.className="check"+(v!==null&&v!==undefined?" complete":"");const icon=document.createElement("span");icon.className="check-icon";icon.textContent=v!==null&&v!==undefined?"✓":"·";const body=document.createElement("div");const strong=document.createElement("strong");strong.textContent=label;const small=document.createElement("small");small.textContent=labelValue(key,v);body.append(strong,small);el.append(icon,body);list.appendChild(el);});
 const out=state.outcome||"In progress";document.querySelector("#outcome").textContent=out.replaceAll("_"," ").replace(/\b\w/g,c=>c.toUpperCase());
 document.querySelector("#outcomeText").textContent=state.outcome? "Conversation ended with outcome: "+out+". Select Start over to run another scenario.":"Complete the conversation to see the result.";
 document.querySelector("#statusText").textContent=state.outcome?"Conversation ended":"Conversation in progress";
 document.querySelector("#statusDot").classList.toggle("done",!!state.outcome);
 document.querySelector("#turnCount").textContent=`${state.history.length} messages`;
 document.querySelector("#sendBtn").disabled=!!state.outcome;
 input.disabled=!!state.outcome;
}
async function sendMessage(message){
 if(!message.trim()||state.outcome)return;
 addBubble("customer",message);state.history.push({role:"user",text:message});input.value="";
 try{
  const response=await fetch("/api/respond",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message,state})});
  const data=await response.json();if(!response.ok)throw new Error(data.error||"Request failed");
  state=data.state;addBubble("assistant",data.reply);render();
 }catch(err){addBubble("assistant","Sorry, the demo server could not process that turn. Check that the Node.js server is running.");}
}
form.addEventListener("submit",e=>{e.preventDefault();sendMessage(input.value);});
document.querySelectorAll("[data-message]").forEach(btn=>btn.addEventListener("click",()=>sendMessage(btn.dataset.message)));
document.querySelector("#resetBtn").addEventListener("click",()=>{
 state={stage:"identity",identityVerified:false,consent:false,answers:{propertyType:null,ownership:null,documents:null,loanAmount:null,occupation:null,incomeMode:null,marketValue:null,tenure:null},outcome:null,history:[]};
 chat.innerHTML="";const first="Hello, may I speak with the customer? I'm an AI voice assistant calling on behalf of Home Credit.";state.history.push({role:"assistant",text:first});addBubble("assistant",first);render();input.focus();
});
document.querySelector("#downloadBtn").addEventListener("click",()=>{
 const blob=new Blob([JSON.stringify({project:"Home Credit LAP Voice Agent Demo",exportedAt:new Date().toISOString(),state},null,2)],{type:"application/json"});
 const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download="lap-voice-agent-conversation-log.json";a.click();URL.revokeObjectURL(url);
});
render();
