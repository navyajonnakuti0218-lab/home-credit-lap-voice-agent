const express = require("express");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "Home Credit LAP Voice Agent Demo" }));

app.post("/api/respond", (req, res) => {
  const { message, state } = req.body || {};
  if (!message || typeof message !== "string") return res.status(400).json({ error: "message is required" });
  try {
    res.json(processTurn(message, state || initialState()));
  } catch (e) {
    res.status(500).json({ error: "Could not process message" });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

function initialState() {
  return {
    stage: "identity",
    identityVerified: false,
    consent: false,
    answers: {
      propertyType: null, ownership: null, documents: null, loanAmount: null,
      occupation: null, incomeMode: null, marketValue: null, tenure: null
    },
    outcome: null,
    history: []
  };
}
const requiredOrder = ["propertyType", "ownership", "documents", "loanAmount", "occupation", "incomeMode", "marketValue", "tenure"];
function normalize(s) { return s.toLowerCase().replace(/[₹,]/g, " ").replace(/\s+/g, " ").trim(); }
function money(text) {
  const t = normalize(text);
  let m = t.match(/(\d+(?:\.\d+)?)\s*(crore|crores|cr)\b/);
  if (m) return Number(m[1]) * 10000000;
  m = t.match(/(\d+(?:\.\d+)?)\s*(lakh|lakhs|lac|lacs)\b/);
  if (m) return Number(m[1]) * 100000;
  m = t.match(/(?:rs\.?\s*)?(\d{5,9})(?:\s|$)/);
  if (m) return Number(m[1]);
  m = t.match(/(\d+(?:\.\d+)?)\s*(thousand|k)\b/);
  if (m) return Number(m[1]) * 1000;
  return null;
}
function has(t, words) { return words.some(w => t.includes(w)); }
function extract(message, state) {
  const t = normalize(message), a = state.answers;
  // Capture out-of-order details from each customer turn.
  if (!a.propertyType) {
    if (has(t, ["agricultural", "agriculture", "farm land", "farmland"])) a.propertyType = "agricultural";
    else if (has(t, ["residential", "house", "flat", "apartment"])) a.propertyType = "residential";
    else if (has(t, ["commercial", "shop", "office"])) a.propertyType = "commercial";
    else if (has(t, ["industrial", "factory"])) a.propertyType = "industrial";
  }
  if (!a.ownership) {
    if (has(t, ["joint", "jointly", "co-owner", "co owner", "shared ownership"])) a.ownership = "joint";
    else if (has(t, ["sole owner", "solely", "only owner", "my property", "own it myself"])) a.ownership = "sole";
  }
  if (!a.documents) {
    if (has(t, ["don't have original", "do not have original", "no original", "only copies", "photocopies", "not available"])) a.documents = "no";
    else if (has(t, ["original documents", "original papers", "documents are ready", "have the originals", "yes, originals", "yes originals"])) a.documents = "yes";
  }
  if (!a.loanAmount) {
    const v = money(t);
    if (v !== null && has(t, ["lakh", "lakhs", "lac", "lacs", "crore", "crores", " rupee", "rs", "₹"]) || /^\d{5,9}$/.test(t)) {
      a.loanAmount = v;
    }
  }
  if (!a.occupation) {
    if (has(t, ["self-employed", "self employed", "business owner", "i run a business", "own business"])) a.occupation = "self-employed";
    else if (has(t, ["salaried", "salary", "job", "employed"])) a.occupation = "salaried";
  }
  if (!a.incomeMode) {
    if (has(t, ["cash", "in hand", "paid in cash"])) a.incomeMode = "cash";
    else if (has(t, ["bank", "bank account", "bank transfer", "salary account"])) a.incomeMode = "bank";
  }
  if (!a.marketValue) {
    const v = money(t);
    if (v !== null && has(t, ["value", "worth", "market", "property is", "property worth"])) a.marketValue = v;
  }
  if (!a.tenure) {
    let m = t.match(/(\d+(?:\.\d+)?)\s*(years|year|yrs|yr)\b/);
    if (m) a.tenure = Number(m[1]);
    else if (has(t, ["ten years", "tenure of ten"])) a.tenure = 10;
  }
}
function moneyLabel(v) { return "₹" + Number(v).toLocaleString("en-IN"); }
function nextQuestion(state) {
  const a = state.answers;
  if (!a.propertyType) return "What type of property would you like to use: residential, commercial, or industrial?";
  if (!a.ownership) return "Is the property solely owned by you, or is it jointly owned with family members or partners?";
  if (!a.documents) return "Are the original property documents available for verification?";
  if (!a.loanAmount) return "How much would you like to borrow? The maximum amount under this offer is ₹75 lakh.";
  if (!a.occupation) return "Are you salaried, or are you self-employed?";
  if (!a.incomeMode) return "Is your income received through a bank or in cash?";
  if (!a.marketValue) return "What is your estimate of the property's current market value?";
  if (!a.tenure) return "How many years would you like to take to repay the loan? The available tenure is 3 to 15 years.";
  return null;
}
function processTurn(message, state) {
  const t = normalize(message);
  state.history = state.history || [];
  if (state.outcome) return { reply: "This demo conversation has ended. Select “Start over” to test another scenario.", state };
  state.history.push({ role: "user", text: message });

  if (has(t, ["already have a loan", "existing loan", "reduce my emi", "reduce emi", "lower my emi", "loan transfer", "transfer my loan"])) {
    state.outcome = "loan_transfer_specialist";
    return finish(state, "Understood. Since you're asking about an existing property loan or reducing your EMI, a loan-transfer specialist is the right person to help. They will contact you shortly. Thank you for your time.");
  }
  if (has(t, ["don't call", "do not call", "stop calling", "not interested", "no thanks", "not interested at all"])) {
    state.outcome = has(t, ["don't call", "do not call", "stop calling"]) ? "do_not_contact" : "declined";
    return finish(state, "I understand. Thank you for your time. I won't continue with the eligibility questions.");
  }
  if (has(t, ["busy", "in a meeting", "call me later", "another time", "not now"])) {
    state.outcome = "callback_requested";
    return finish(state, "Of course. What day and time would be convenient for a callback? This demo can capture your preference, but it cannot schedule a real callback.");
  }
  if (!state.identityVerified) {
    if (has(t, ["yes", "speaking", "this is", "that's me", "that is me"])) {
      state.identityVerified = true;
      return reply(state, "Thank you for confirming. I'm calling on behalf of Home Credit about a Loan Against Property offer of up to ₹75 lakh, subject to eligibility checks and final review by a loan expert. Would you be happy to spend a few minutes on a preliminary eligibility check?");
    }
    if (has(t, ["no", "wrong person", "who is this", "not me"])) {
      state.outcome = "wrong_party";
      return finish(state, "I'm sorry for the interruption. I won't share any offer details. Thank you, and goodbye.");
    }
    return reply(state, "Hello, may I speak with the customer? I'm an AI voice assistant calling on behalf of Home Credit.");
  }
  if (!state.consent) {
    if (has(t, ["yes", "okay", "ok", "sure", "go ahead", "fine", "proceed"])) {
      state.consent = true;
      return reply(state, "Thank you. I'll ask a few short questions. " + nextQuestion(state));
    }
    if (has(t, ["no", "not now", "don't want"])) {
      state.outcome = "declined";
      return finish(state, "No problem. Thank you for your time. Have a good day.");
    }
    return reply(state, "Would you like to continue with the preliminary eligibility check?");
  }

  extract(message, state);
  const a = state.answers;
  if (a.propertyType === "agricultural") {
    state.outcome = "disqualified_property_type";
    return finish(state, "Thank you for clarifying. This specific offer currently covers residential, commercial, and industrial properties, not agricultural property. I'm sorry we can't proceed with this offer at this time.");
  }
  if (a.propertyType && !["residential", "commercial", "industrial"].includes(a.propertyType)) {
    state.outcome = "disqualified_property_type";
    return finish(state, "This specific offer supports residential, commercial, and industrial properties only, so we can't proceed with this property type. Thank you for your time.");
  }
  if (a.documents === "no") {
    state.outcome = "disqualified_documents";
    return finish(state, "The original property documents must be available for verification. Since they aren't available, we can't proceed with this specific offer at this time. Thank you for your time.");
  }
  if (a.loanAmount && a.loanAmount > 7500000) {
    a.loanAmount = null;
    return reply(state, "The maximum amount under this offer is ₹75 lakh. Would you like to proceed with a request for ₹75 lakh instead?");
  }
  if (a.incomeMode === "cash") {
    state.outcome = "disqualified_income_mode";
    return finish(state, "Thank you for clarifying. For this offer, income must be received through a bank. We can't proceed under the stated criteria at this time. Thank you for your time.");
  }
  if (a.tenure !== null && a.tenure !== undefined && (a.tenure < 3 || a.tenure > 15)) {
    a.tenure = null;
    return reply(state, "The available repayment tenure is between 3 and 15 years. What tenure within that range would work for you?");
  }
  const q = nextQuestion(state);
  if (q) return reply(state, "Understood. " + q);
  state.outcome = "qualified_for_handoff";
  return finish(state, `Thank you. I have recorded your preliminary details: ${a.propertyType} property, ${a.ownership} ownership, original documents ${a.documents === "yes" ? "available" : "not confirmed"}, requested amount ${moneyLabel(a.loanAmount)}, ${a.occupation}, income through ${a.incomeMode}, estimated property value ${moneyLabel(a.marketValue)}, and tenure ${a.tenure} years. Based on the information shared, you appear to meet the preliminary criteria. A senior loan expert would need to review your case and confirm applicable interest rates and next steps. This is not final loan approval.`);
}
function reply(state, text) { state.history.push({ role: "assistant", text }); return { reply: text, state }; }
function finish(state, text) { state.history.push({ role: "assistant", text }); return { reply: text, state, ended: true }; }

app.listen(PORT, () => console.log(`Home Credit LAP Voice Agent demo running at http://localhost:${PORT}`));
