# Home Credit LAP Voice Agent — VS Code Project

A lightweight Node.js web application demonstrating the Home Credit Loan Against Property (LAP) qualification flow from the hiring assignment.

## What this project includes
- Responsive web dashboard and simulated customer chat
- Node.js + Express API
- Eligibility checklist with live extracted fields
- Immediate disqualification and loan-transfer routing examples
- Quick scenario buttons
- Downloadable JSON conversation log
- Separate `SYSTEM_PROMPT.txt` for use on Retell AI / Bolna

## Important limitations
This is a **local demo simulator**, not a production voice agent. It does not place phone calls, provide a real public voice-agent URL, schedule callbacks, connect to Home Credit systems, or generate platform call recordings. The web chat is text-based. For the assessment's voice requirement, paste `SYSTEM_PROMPT.txt` into Retell AI, Bolna, or another permitted voice platform and run actual test calls. Do not claim simulated chats are call recordings.

The eligibility extractor is a simple demo parser, not a reliable financial decision engine. Review and test all cases before presenting it.

## Requirements
- Node.js 18 or later
- VS Code

## Run locally
1. Extract the ZIP.
2. Open the extracted folder in VS Code.
3. Open Terminal → New Terminal.
4. Run:

   ```bash
   npm install
   npm start
   ```

5. Open http://localhost:3000 in your browser.

## Suggested demo flow
1. Click **Confirm identity**.
2. Click **Continue**.
3. Enter customer answers naturally or use the quick test buttons.
4. Observe the checklist and outcome panel.
5. Click **Download conversation log (.json)** to export the simulated transcript and state.

## Deploy the web demo (optional)
You can deploy the Node app to a Node-compatible host such as Render or Railway. Configure the start command as `npm start`. Deployment may require a hosting account and may have costs/usage limits. A deployed web demo is not a substitute for the required voice-platform recordings/logs.

## Assessment submission checklist
- [ ] System prompt configured in a voice platform
- [ ] Professional voice selected and language configured
- [ ] Test calls run for eligible and disqualified customers, busy state, out-of-order answers, loan transfer, and loan amount/tenure limits
- [ ] Audio and transcript logs saved
- [ ] Public recording/log link tested in an incognito/private browser
- [ ] Screen recording of the working agent saved to Drive
- [ ] Submit links and prompt with honest completion status

## Runtime variables from the assignment
The standalone prompt references:
`company_name`, `customer_name`, `agent_name`, `agent_gender`, `current_date`, `current_day`, `current_time`, `additional_context_from_rag`, `language_to_speak`, `conversation_history`, `customer_utterance`.

Use fictional customer details for demonstrations. Do not enter real customer financial information.
